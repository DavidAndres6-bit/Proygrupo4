package diegoDeAlba_Proy2Trim;

import java.util.Arrays;
	
	public class Piscina {
	    private int numCalles;
	    private int maxPorCalle;
	    private int[] reservasCalles;

    public Piscina(int numCalles, int maxPorCalle) {
        this.numCalles = numCalles;
        this.maxPorCalle = maxPorCalle;
        this.reservasCalles = new int[numCalles];
        // Por defecto todas 0
    }

	public int getNumCalles() {
		return numCalles;
	}

	public void setNumCalles(int numCalles) {
		this.numCalles = numCalles;
	}

	public int getMaxPorCalle() {
		return maxPorCalle;
	}

	public void setMaxPorCalle(int maxPorCalle) {
		this.maxPorCalle = maxPorCalle;
	}

	public int[] getReservasCalles() {
		return reservasCalles;
	}

	public void setReservasCalles(int[] reservasCalles) {
		this.reservasCalles = reservasCalles;
	}
	
    public boolean reservar(int calle) {
    	boolean reservado;
    	
        if(calle < 0 || calle >= numCalles) {
            reservado= false; // calle inexistente
          
        }else {
	        
	        if(reservasCalles[calle] < maxPorCalle) {
	            reservasCalles[calle]++;
	            reservado=true;
	            
	        } else {
	            reservado= false; // lleno
	        }
        }
        return reservado;
    }
    
    public void mostrarEstado() {
    	
        System.out.println("Estado de la piscina:");
        
        for(int i = 0; i < numCalles; i++) {
        	
            int reservadas = reservasCalles[i];
            String estado;
            
            if(reservadas == 0) {
                estado = "[Disponible: 0/" + maxPorCalle + "]";
                
            } else if(reservadas < maxPorCalle) {
                estado = "[Ocupación parcial: " + reservadas + "/" + maxPorCalle + "]";
                
            } else {
                estado = "[COMPLETO: " + reservadas + "/" + maxPorCalle + "]";
                
            }
            
            System.out.println("  Calle " + i + ": " + estado);
        }
    }

	@Override
	public String toString() {
		return super.toString()+ "Piscina [numCalles=" + numCalles + ", maxPorCalle=" + maxPorCalle + ", reservasCalles="
				+ Arrays.toString(reservasCalles) + "]";
		}
	    
	    
	    
	    
}
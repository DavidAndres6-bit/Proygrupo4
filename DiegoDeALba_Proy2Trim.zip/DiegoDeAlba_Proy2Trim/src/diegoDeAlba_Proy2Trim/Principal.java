package diegoDeAlba_Proy2Trim;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  GestionGimnasio gestion = new GestionGimnasio("\u001B[34mAtlas\u001B[0m");
	        gestion.iniciarSistema();

	}

}

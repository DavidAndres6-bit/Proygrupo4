package diegoDeAlba_Proy2Trim;

public class AbonoBasico extends Abono {
	
    private int clasesConsumidas;
    public static final int MAX_CLASES = 15;
    
    public AbonoBasico(String nombre, int edad) {
        super(nombre, edad);
        this.clasesConsumidas = 0;
    }

	public int getClasesConsumidas() {
		return clasesConsumidas;
	}

	public void setClasesConsumidas(int clasesConsumidas) {
		this.clasesConsumidas = clasesConsumidas;
	}

	public static int getMaxClases() {
		return MAX_CLASES;
	}
    
	public boolean registrarClase(int clasesGastadas) {
		boolean registrada=false;
		
		if (clasesConsumidas<MAX_CLASES) {
		this.clasesConsumidas+=clasesGastadas;
		registrada=true;
		
		}
		return registrada;
	}
    @Override
    public double calcularCoste() {
        // Abono básico = cuotaBase sin recargo
        return this.cuotaBase;
    }

	@Override
	public String toString() {
		return super.toString()+"\tClases Consumidas=" + clasesConsumidas ;
	}
    
    
}

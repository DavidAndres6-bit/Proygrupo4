package diegoDeAlba_Proy2Trim;

public class RegistroAbonados {
	
    private Abono[] abonados;
    private int contadorAbonados;
    private final int MAX_ABONADOS = 50;
    private Interfaz interfaz; 

    public RegistroAbonados(Interfaz interfaz) {
        this.interfaz =new  Interfaz();
        abonados = new Abono[MAX_ABONADOS];
        contadorAbonados = 0;
        
        
        // Datos iniciales de ejemplo:

        añadirAbono(new AbonoBasico("Juan", 30));
        añadirAbono(new AbonoPremium("María", 40,  "Carlos", true));
        añadirAbono(new AbonoInfantil("Luis", 8,  "Ana"));
        añadirAbono(new AbonoBasico("Pedro", 25));
        añadirAbono(new AbonoPremium("Laura", 50, "Marta", false));
        añadirAbono(new AbonoInfantil("Sofía", 10, "Elena"));
        añadirAbono(new AbonoBasico("Luna", 35));
        añadirAbono(new AbonoPremium("Fer", 45, "David", true));
        añadirAbono(new AbonoInfantil("Alex", 7, "Rosa"));
        añadirAbono(new AbonoBasico("Diego", 28));
        
    }
    
    
    
    public Abono[] getAbonados() {
		return abonados;
	}



	public void setAbonados(Abono[] abonados) {
		this.abonados = abonados;
	}



	public int getContadorAbonados() {
		return contadorAbonados;
	}



	public void setContadorAbonados(int contadorAbonados) {
		this.contadorAbonados = contadorAbonados;
	}



	public Interfaz getInterfaz() {
		return interfaz;
	}



	public void setInterfaz(Interfaz interfaz) {
		this.interfaz = interfaz;
	}



	public int getMAX_ABONADOS() {
		return MAX_ABONADOS;
	}



	public void crearNuevoAbono() {
    	
        int tipo = interfaz.leerEntero("\nElige el tipo de abono (1: Básico, 2: Premium, 3: Infantil): ");
        String nombre = interfaz.leerDato("Nombre: ");
        int edad = interfaz.leerEntero("Edad: ");
        
        switch(tipo) {
        
            case 1:
                añadirAbono(new AbonoBasico(nombre, edad));
                break;
            case 2:
                String entrenador = interfaz.leerDato("Nombre del entrenador: ");
                String spa = interfaz.leerDato("¿Acceso a Spa? (si/no): ");
                boolean accesoSpa = spa.equalsIgnoreCase("si");
                añadirAbono(new AbonoPremium(nombre, edad,  entrenador, accesoSpa));
                break;
            case 3:
                String tel = interfaz.leerDato("Teléfono del tutor: ");
                añadirAbono(new AbonoInfantil(nombre, edad,  tel));
                break;
            default:
                interfaz.mostrarMensaje("Tipo no válido.");
                break;
        }
        interfaz.mostrarMensaje("Abono creado correctamente.");
    }

    public void añadirAbono(Abono a) {
    	
        if(contadorAbonados < MAX_ABONADOS) {
            abonados[contadorAbonados] = a;
            contadorAbonados++;
        } else {
            interfaz.mostrarMensaje("Registro lleno. No se puede añadir más abonados.");
        }
    }

    public void mostrarAbonados() {
    	
        if(contadorAbonados == 0) {
            interfaz.mostrarMensaje("No hay abonados registrados.");
           
        } else {
        	
	        interfaz.mostrarMensaje("\nLista de Abonados:");
	        for (int i = 0; i < contadorAbonados; i++) {
	            interfaz.mostrarMensaje(abonados[i].toString());
	        }
        }
    }

    public Abono buscarAbono(int id) {
    	
        Abono resultado = null;
        
        for (int i = 0; i < contadorAbonados && resultado == null; i++) {
            if (abonados[i].getIdSocio() == id) {
                resultado = abonados[i];
            }
        }
        return resultado;
    }
    
    public void consultarDatosAbono(int id) {
        Abono a = buscarAbono(id);
        if(a != null) {
            interfaz.mostrarMensaje(a.toString());
            interfaz.mostrarMensaje("Coste mensual: " + a.calcularCoste() + " €");
            
        } else {
        	
            interfaz.mostrarMensaje("No se encontró abonado con ID " + id);
        }
    }

    public void bajaAbono(int id) {
        Abono a = buscarAbono(id);
        
        if(a != null) {
            if(!a.isActivo()) {
                interfaz.mostrarMensaje("El abono ya estaba dado de baja.");
                
            } else {
                a.setActivo(false);
                interfaz.mostrarMensaje("Abono dado de baja.");
            }
            
        } else {
        	
            interfaz.mostrarMensaje("No se encontró abonado con ID " + id);
        }
    }

    public void activarAbono(int id) {
        Abono a = buscarAbono(id);
        
        if(a != null) {
        	
            if(a.isActivo()) {
                interfaz.mostrarMensaje("El abono ya está activo.");
                
            } else {
                a.setActivo(true);
                interfaz.mostrarMensaje("Abono activado.");
            }
            
        } else {
            interfaz.mostrarMensaje("No se encontró abonado con ID " + id);
        }
    }

    public double totalRecaudacion() {
        double total = 0;
        for (int i = 0; i < contadorAbonados; i++) {
            if(abonados[i].isActivo())
                total += abonados[i].calcularCoste();
        }
        return total;
    }
    
    public int totalAbonados() {
    	return contadorAbonados;
    }
    

    public int totalActivos() {
        int total = 0;
        for (int i = 0; i < contadorAbonados; i++) {
            if(abonados[i].isActivo())
                total++;
        }
        return total;
    }
    
    public int totalBajas() {
    	return totalAbonados()-totalActivos();
    }
    
    public double mediaEdad() {
        int media = 0;
        
        for (int i = 0; i < contadorAbonados; i++) {
            media+=abonados[i].getEdad();
            
        }
        
        media=media/contadorAbonados;
        return media;
    	
    }
 
}
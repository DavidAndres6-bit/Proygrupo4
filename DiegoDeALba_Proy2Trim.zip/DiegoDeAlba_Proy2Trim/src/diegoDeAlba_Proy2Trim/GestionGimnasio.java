package diegoDeAlba_Proy2Trim;

public class GestionGimnasio {
	private String nombreGimnasio;
	private RegistroAbonados registro;
	private Piscina piscina;
	private Yoga yoga;
	private String contrasena;
	private Interfaz interfaz;
	    
	public GestionGimnasio(String nombre) {
        this.nombreGimnasio = nombre;
        this.registro = new RegistroAbonados(interfaz);
        this.piscina = new Piscina(6, 5);
        this.yoga = new Yoga(25);
        this.contrasena = "admin1234";
        this.interfaz = new Interfaz();
    }
    
    public void iniciarSistema() {
    	
        interfaz.mostrarMensaje("Bienvenido a " + nombreGimnasio);
        int intentos = 3;
        boolean acceso = false;
        
        while(intentos > 0 && !acceso) {
        	
            String pass = interfaz.leerDato("Introduce la contraseña: ");
            
            if(pass.equals(contrasena)) {
                acceso = true;
              
           } else {
                intentos--;
                interfaz.mostrarMensaje("Contraseña incorrecta. Te quedan " + intentos + " intentos.");
           }
       }
        
       if(!acceso) {
            interfaz.mostrarMensaje("\u001B[31mSistema bloqueado.");
           
       }
        
       if(acceso) {
        	
	       char opcion = interfaz.leerCaracter("\n--- Menú del Sistema ---\n" +
	                                         "a. Mostrar abonados\n" +
	                                         "b. Consultar datos de abono\n" +
	                                         "c. Nuevo abono\n" +
	                                         "d. Baja de abono\n" +
	                                         "e. Activar abono\n" +
	                                         "f. Ver estadísticas\n" +
	                                         "g. Reservar clase\n" +
	                                         "h. Mostrar estado de clases dirigidas\n" +
	                                         "i. Cambiar contraseña\n" +
	                                         "s. Salir\n" +
	                                         "Elige una opción: ");
	        
	        while(opcion != 's') {
	        	
	            switch(opcion) {
	            
	                case 'a':
	                    registro.mostrarAbonados();
	                    break;
	                    
	                case 'b':
	                	
	                    int idConsulta = interfaz.leerEntero("Introduce el ID del abonado: ");
	                    registro.consultarDatosAbono(idConsulta);
	                    break;
	                    
	                case 'c':
	                	
	                    registro.crearNuevoAbono();
	                    break;
	               
	                case 'd':
	                    int idBaja = interfaz.leerEntero("Introduce el ID para dar de baja: ");
	                    registro.bajaAbono(idBaja);
	                    break;
	                    
	                case 'e':
	                	
	                    int idAct = interfaz.leerEntero("Introduce el ID para activar: ");
	                    registro.activarAbono(idAct);
	                    break;
	                    
	                case 'f':
	                	interfaz.mostrarMensaje("Abonados Totales: " + registro.totalAbonados());
	                    interfaz.mostrarMensaje("Abonados activos: " + registro.totalActivos());
	                    interfaz.mostrarMensaje("Abonados de baja: " + registro.totalBajas());
	                    interfaz.mostrarMensaje("Media de edad: " + registro.mediaEdad());
	                    interfaz.mostrarMensaje("Recaudación total: " + registro.totalRecaudacion() + " €");
	                    break;
	                    
	                case 'g':
	                	
	                    reservarClase();
	                    break;
	                    
	                case 'h':
	                	
	                    piscina.mostrarEstado();
	                    yoga.mostrarEstado();
	                    break;
	                    
	                case 'i':
	                	
	                    cambiarContrasena();
	                    break;
	                    
	                default:
	                    interfaz.mostrarMensaje("Opción no válida.");
	            }
	            
	            opcion = interfaz.leerCaracter("\n--- Menú del Sistema ---\n" +
	                                         "a. Mostrar abonados\n" +
	                                         "b. Consultar datos de abono\n" +
	                                         "c. Nuevo abono\n" +
	                                         "d. Baja de abono\n" +
	                                         "e. Activar abono\n" +
	                                         "f. Ver estadísticas\n" +
	                                         "g. Reservar clase\n" +
	                                         "h. Mostrar estado de clases dirigidas\n" +
	                                         "i. Cambiar contraseña\n" +
	                                         "s. Salir\n" +
	                                         "Elige una opción: ");
	        }
	        interfaz.mostrarMensaje("Saliendo del sistema...");
        }
    }
    

    private void reservarClase() {
    	
        String mensaje = "\nIntroduce el ID del abonado para reservar: ";
        int id = interfaz.leerEntero(mensaje);
        Abono abono = registro.buscarAbono(id);

        if (abono == null || !abono.isActivo()) {
            mensaje = "Abonado no encontrado o inactivo.";
            
        } else {
            int opcionClase = interfaz.leerEntero("Elige la clase a reservar (1: Piscina, 2: Yoga): ");

            if (opcionClase == 1) { // Reserva en piscina
            	
                mensaje = (abono.getClass() == AbonoBasico.class) ? "Los abonados básicos no pueden reservar piscina.": (piscina.reservar(interfaz.leerEntero("Introduce el número de calle (0 a 5): ")) ? "\u001B[32mReserva en piscina exitosa.\u001B[0m" : "\u001B[31mReserva fallida, calle completa.\u001B[0m");
                
            } else if (opcionClase == 2) { // Reserva en yoga
            	
                if (abono.getClass() == AbonoInfantil.class) {
                    mensaje = "Los abonados infantiles no pueden reservar yoga.";
                    
                } else {
                	
                    if (abono.getClass() == AbonoBasico.class) {
                        AbonoBasico abB = (AbonoBasico) abono;
                        
                        mensaje = (abB.getClasesConsumidas() >= AbonoBasico.MAX_CLASES) ? "Límite de clases alcanzado." : (abB.registrarClase(1) && yoga.reservar() ? "\u001B[32mReserva de yoga exitosa.\u001B[0m" : "\u001B[33mClase de yoga completa.\u001B[0m");
                        
                    } else {
                    	
                        mensaje = yoga.reservar() ? "\u001B[32mReserva de yoga exitosa.\u001B[0m" : "\u001B[33mClase de yoga completa.\u001B[0m";
                        
                    }
                }
                
            } else {
            	
                mensaje = "Opción no válida.";
            }
        }
        interfaz.mostrarMensaje(mensaje);
    }
    
    private void cambiarContrasena() {
    	
        String nueva = interfaz.leerDato("\nIntroduce la nueva contraseña: ");
        String confirmacion = interfaz.leerDato("Confirma la nueva contraseña: ");
        
        if(nueva.equals(confirmacion) && validarContrasena(nueva)) {
            contrasena = nueva;
            interfaz.mostrarMensaje("\u001B[32mContraseña cambiada correctamente.\u001B[0m");
            
        } else {
            interfaz.mostrarMensaje("\u001B[31mError: Las contraseñas no coinciden o no cumplen los requisitos (mínimo 8 caracteres, 1 mayúscula, 1 minúscula y 1 dígito).\u001B[0m");
        }
    }
    
    private boolean validarContrasena(String pass) {
    	
        if(pass.length() < 8) return false;
        boolean mayus = false, minus = false, digito = false;
        for(char c : pass.toCharArray()){
            if(Character.isUpperCase(c)) mayus = true;
            if(Character.isLowerCase(c)) minus = true;
            if(Character.isDigit(c)) digito = true;
        }
        return mayus && minus && digito;
    }
}

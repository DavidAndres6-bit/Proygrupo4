package diegoDeAlba_Proy2Trim;

public class Yoga {
	
    private int plazasTotales;
    private int plazasOcupadas;

    public Yoga(int plazasTotales) {
        this.plazasTotales = plazasTotales;
        this.plazasOcupadas = 0;
    }

	public int getPlazasTotales() {
		return plazasTotales;
	}

	public void setPlazasTotales(int plazasTotales) {
		this.plazasTotales = plazasTotales;
	}

	public int getPlazasOcupadas() {
		return plazasOcupadas;
	}

	public void setPlazasOcupadas(int plazasOcupadas) {
		this.plazasOcupadas = plazasOcupadas;
	}
    public boolean reservar() {
    	
    	boolean reservar = false;
        if(plazasOcupadas < plazasTotales) {
            plazasOcupadas++;
            reservar= true;
        }
        return reservar;
    }
    
    public void mostrarEstado() {
        System.out.println("\nEstado de la clase de Yoga: " + plazasOcupadas + " / " + plazasTotales);
    }
    
}
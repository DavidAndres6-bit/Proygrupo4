package diegoDeAlba_Proy2Trim;

import java.util.Scanner;

public class Interfaz {
	
    private Scanner sc;
    
    public Interfaz() {
        sc = new Scanner(System.in);
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public String leerDato(String mensaje) {
        System.out.print(mensaje);
        
        String dato = sc.nextLine();
        
        return  dato;
    }
    
    public int leerEntero(String mensaje) {
    	
        int resultado = 0;
        mostrarMensaje(mensaje);
        resultado=sc.nextInt();
        return resultado;
    }


    public char leerCaracter(String mensaje) {
        String input = leerDato(mensaje);
        return input.length() > 0 ? Character.toLowerCase(input.charAt(0)) : ' ';
    }
}

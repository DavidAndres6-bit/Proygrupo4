package diegoDeAlba_Proy2Trim;

public abstract class Abono {
	private int idSocio;
    private String nombre;
    private int edad;
    protected double cuotaBase =35;
    private boolean activo;
    
    public Abono(String nombre, int edad) {
        this.idSocio = (int)(Math.random() * 9000) + 1000;
        this.nombre = nombre;
        this.edad = edad;
        this.activo = true;
    }

	public int getIdSocio() {
		return idSocio;
	}

	public void setIdSocio(int idSocio) {
		this.idSocio = idSocio;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public double getCuotaBase() {
		return cuotaBase;
	}

	public void setCuotaBase(double cuotaBase) {
		this.cuotaBase = cuotaBase;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}
	
    public abstract double calcularCoste();
    
    @Override
    public String toString() {
        return "ID: " + idSocio +
               "\t| Nombre: " + nombre +
               "\t| Edad: " + edad +
               "\t| Activo: " + (activo ? "Sí" : "No");
    }
}




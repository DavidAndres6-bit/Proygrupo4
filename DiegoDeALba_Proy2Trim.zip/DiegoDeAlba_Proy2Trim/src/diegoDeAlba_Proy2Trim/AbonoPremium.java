package diegoDeAlba_Proy2Trim;

public class AbonoPremium extends Abono {
	
    private String nombreEntrenador;
    private boolean accesoSpa;
    public static double COSTE_SPA = 25.0;
    
    public AbonoPremium(String nombre, int edad,  String nombreEntrenador, boolean accesoSpa) {
        super(nombre, edad);
        this.nombreEntrenador = nombreEntrenador;
        this.accesoSpa = accesoSpa;
    }

	public String getNombreEntrenador() {
		return nombreEntrenador;
	}

	public void setNombreEntrenador(String nombreEntrenador) {
		this.nombreEntrenador = nombreEntrenador;
	}

	public boolean isAccesoSpa() {
		return accesoSpa;
	}

	public void setAccesoSpa(boolean accesoSpa) {
		this.accesoSpa = accesoSpa;
	}

	public static double getCOSTE_SPA() {
		return COSTE_SPA;
	}


	@Override
	public double calcularCoste() {
		
		double costePremium ;
		
		costePremium= cuotaBase+(cuotaBase*0.2);
		
		if(this.accesoSpa) {
			cuotaBase+=25;
		}
		return costePremium;
	}

	@Override
	public String toString() {
		return super.toString()+ "\tNombre Entrenador=" + nombreEntrenador + ", Acceso Spa =" + accesoSpa ;
	}
    
	

}

package diegoDeAlba_Proy2Trim;

public class AbonoInfantil extends Abono {
	
    private String telTutor;
    
    public AbonoInfantil(String nombre, int edad,  String telTutor) {
        super(nombre, edad);
        this.telTutor = telTutor;
    }

	public String getTelTutor() {
		return telTutor;
	}

	public void setTelTutor(String telTutor) {
		this.telTutor = telTutor;
	}

	@Override
	public double calcularCoste() {
		
		double costeInfantil=0;
		
		if(getEdad()>=7 && getEdad()<=14) {
			costeInfantil=cuotaBase*0.75;
		} else if (super.getEdad()<=6) {
			costeInfantil=cuotaBase*0.5;
		}
		
		return costeInfantil;
	}

	@Override
	public String toString() {
		return super.toString()+ "\tTelefono Tutor=" + telTutor ;
	}
    
	

}
